# lit.rudy Website

This is a ready website/PWA version of lit.rudy.

## Open locally
Double-click `index.html` to preview the website.

## Publish for free with Vercel
1. Create a GitHub account.
2. Create a new repository named `lit-rudy-website`.
3. Upload all files from this folder.
4. Go to vercel.com and sign in with GitHub.
5. Click **Add New Project**.
6. Choose `lit-rudy-website`.
7. Click **Deploy**.
8. Your website will get a free link.

## Add AI answers
1. In Vercel, open the project.
2. Go to Settings > Environment Variables.
3. Add `OPENAI_API_KEY`.
4. Redeploy.

## Install on phone
- iPhone: open the website in Safari > Share > Add to Home Screen.
- Android: open the website in Chrome > Install app / Add to Home Screen.
