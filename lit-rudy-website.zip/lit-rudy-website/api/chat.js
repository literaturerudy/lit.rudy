export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  const { question } = req.body || {};
  if (!question) return res.status(400).json({ error: 'Question is required' });

  if (!process.env.OPENAI_API_KEY) {
    return res.status(200).json({ answer: 'Backend is ready, but OPENAI_API_KEY is not set yet. Add it in Vercel Environment Variables.' });
  }

  const response = await fetch('https://api.openai.com/v1/responses', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`
    },
    body: JSON.stringify({
      model: 'gpt-4.1-mini',
      input: [
        {
          role: 'system',
          content: 'You are lit.rudy, a professional literature research assistant. Answer accurately about literature, literary theories, poems, research writing, essays, and theses. Include source suggestions such as books, academic articles, or professional websites. Do not invent exact page numbers or fake citations.'
        },
        { role: 'user', content: question }
      ]
    })
  });

  if (!response.ok) {
    const text = await response.text();
    return res.status(500).json({ error: text });
  }

  const data = await response.json();
  const answer = data.output_text || 'No answer returned.';
  return res.status(200).json({ answer });
}
