const categories = [
  { title: 'American Literature', text: 'Puritan writing, Romanticism, Transcendentalism, Realism, Modernism, Harlem Renaissance, Postmodernism, and contemporary voices.' },
  { title: 'British Literature 16th Century', text: 'Renaissance, Shakespeare, sonnets, drama, humanism, courtly writing, and early modern English culture.' },
  { title: 'British Literature 17th Century', text: 'Metaphysical poetry, Milton, Restoration drama, religious prose, political writing, and civil-war context.' },
  { title: 'British Literature 18th Century', text: 'Neoclassicism, satire, early novels, periodicals, Enlightenment thought, Swift, Pope, Defoe, and Austen’s background.' },
  { title: 'British Literature 19th Century', text: 'Romanticism, Victorian novels, Gothic fiction, industrial society, women writers, Dickens, Brontë, Eliot, Hardy.' },
  { title: 'British Literature 20th Century', text: 'Modernism, war poetry, stream of consciousness, postcolonial writing, drama, and experimental prose.' },
  { title: 'British Literature 21st Century', text: 'Contemporary fiction, identity, migration, memory, feminism, climate writing, digital culture, and global English.' },
  { title: 'Anglo-Saxon Era', text: 'Old English poetry, Beowulf, elegies, heroic code, oral tradition, Christian influence, and manuscript culture.' },
  { title: 'Poems', text: 'Poetic devices, form, meter, imagery, symbolism, voice, tone, close reading, and poem analysis.' },
  { title: 'Literary Theories', text: 'Formalism, structuralism, psychoanalysis, feminism, Marxism, postcolonialism, reader-response, new historicism, ecocriticism.' },
  { title: 'Research Writing', text: 'Research questions, outlines, sources, literature review, methodology, citations, and academic argument.' },
  { title: 'Essays & Theses', text: 'Thesis statements, introductions, body paragraphs, analysis, conclusion, editing, and defense preparation.' }
];

const grid = document.getElementById('categoryGrid');
categories.forEach(item => {
  const card = document.createElement('article');
  card.className = 'card';
  card.innerHTML = `<h3>${item.title}</h3><p>${item.text}</p>`;
  grid.appendChild(card);
});

const demoAnswers = [
  {
    keys: ['anglo', 'saxon', 'beowulf'],
    answer: 'Anglo-Saxon literature, also called Old English literature, includes heroic poetry, religious poems, elegies, riddles, and prose. A key text is Beowulf, which shows heroic values, loyalty, fate, and the tension between pagan and Christian ideas. Suggested sources: The British Library, The Norton Anthology of English Literature, and Cambridge histories of Old English literature.'
  },
  {
    keys: ['modernism', 'modernist'],
    answer: 'Modernism is a literary movement linked to experimentation, fragmentation, stream of consciousness, unreliable narration, and the crisis of identity after rapid social change and war. Key writers include Virginia Woolf, T. S. Eliot, James Joyce, and Katherine Mansfield. Suggested sources: The British Library, Oxford Reference, and The Cambridge Companion to Modernism.'
  },
  {
    keys: ['theory', 'feminist', 'feminism'],
    answer: 'Feminist literary theory studies how literature represents gender, power, patriarchy, women’s voices, and social roles. It asks who speaks, who is silenced, and how female characters and authors are treated. Suggested sources: Elaine Showalter, Sandra Gilbert and Susan Gubar, JSTOR articles, and university literary theory guides.'
  },
  {
    keys: ['essay', 'thesis statement'],
    answer: 'A strong essay needs a clear thesis statement, topic sentences, textual evidence, analysis, and a conclusion that explains why the argument matters. Start with a focused question, then turn your answer into one arguable sentence. Suggested sources: Purdue OWL, university writing centers, and MLA Handbook.'
  },
  {
    keys: ['research', 'thesis', 'dissertation'],
    answer: 'A research paper or thesis should include a clear topic, research problem, literature review, methodology when needed, analysis chapters, conclusion, and accurate citations. The best sources are academic books, peer-reviewed articles, and university databases. Suggested sources: MLA Handbook, Chicago Manual of Style, Purdue OWL, JSTOR, and Project MUSE.'
  }
];

function getDemoAnswer(q) {
  const lower = q.toLowerCase();
  const found = demoAnswers.find(item => item.keys.some(k => lower.includes(k)));
  return found ? found.answer : 'This is the demo version of lit.rudy. For a full answer, connect the included Vercel API to OpenAI. For now, I suggest checking trusted sources such as The British Library, Poetry Foundation, Library of Congress, Purdue OWL, JSTOR, Project MUSE, and university websites. Ask about Anglo-Saxon literature, modernism, feminist theory, essays, research, or thesis writing to see sample answers.';
}

const chatForm = document.getElementById('chatForm');
const input = document.getElementById('questionInput');
const messages = document.getElementById('chatMessages');

function addMessage(text, role) {
  const div = document.createElement('div');
  div.className = `message ${role}`;
  div.textContent = text;
  messages.appendChild(div);
  messages.scrollTop = messages.scrollHeight;
}

chatForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const question = input.value.trim();
  if (!question) return;
  addMessage(question, 'user');
  input.value = '';

  try {
    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ question })
    });
    if (!res.ok) throw new Error('No backend connected');
    const data = await res.json();
    addMessage(data.answer || getDemoAnswer(question), 'bot');
  } catch {
    addMessage(getDemoAnswer(question), 'bot');
  }
});

const notes = document.getElementById('notes');
notes.value = localStorage.getItem('litRudyNotes') || '';
document.getElementById('saveNotes').addEventListener('click', () => {
  localStorage.setItem('litRudyNotes', notes.value);
  alert('Your note is saved on this device.');
});

let mediaRecorder;
let chunks = [];
const recordBtn = document.getElementById('recordBtn');
const status = document.getElementById('recordStatus');
recordBtn.addEventListener('click', async () => {
  if (mediaRecorder && mediaRecorder.state === 'recording') {
    mediaRecorder.stop();
    recordBtn.textContent = 'Start recording';
    status.textContent = 'Recording stopped.';
    return;
  }
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    mediaRecorder = new MediaRecorder(stream);
    chunks = [];
    mediaRecorder.ondataavailable = e => chunks.push(e.data);
    mediaRecorder.onstop = () => {
      const blob = new Blob(chunks, { type: 'audio/webm' });
      const url = URL.createObjectURL(blob);
      status.innerHTML = `<a href="${url}" download="lit-rudy-note.webm">Download recording</a>`;
    };
    mediaRecorder.start();
    recordBtn.textContent = 'Stop recording';
    status.textContent = 'Recording...';
  } catch {
    status.textContent = 'Microphone permission was not allowed.';
  }
});

if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('service-worker.js');
}
